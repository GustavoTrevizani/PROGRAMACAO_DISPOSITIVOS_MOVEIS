package com.example.basquete;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    public RadioButton bt1;
    public RadioButton bt2;
    public Button Bola1;
    public Button Bola2;
    public Button Bola3;
    public TextView RTime1;
    public TextView RTime2;
    public int pontot1=0;
    public int pontot2=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bt1 = findViewById(R.id.radioTime1);
        bt2 = findViewById(R.id.radioTime2);
        Bola1 = findViewById(R.id.buttonBola1);
        Bola2 = findViewById(R.id.buttonBola2);
        Bola3 = findViewById(R.id.buttonBola3);
        RTime1 = findViewById(R.id.R1);
        RTime2 = findViewById(R.id.R2);
    }

    public void cBola1(View view){
        if (bt1.isChecked()){
            pontot1 = pontot1+1;
            RTime1.setText(" " + pontot1);
        }
        else if(bt2.isChecked()){
            pontot2 = pontot2+1;
            RTime2.setText(" " + pontot2);
        }
    }

    public void cBola2(View view){
        if (bt1.isChecked()){
            pontot1 = pontot1+2;
            RTime1.setText(" " + pontot1);
        }
        else if(bt2.isChecked()){
            pontot2 = pontot2+2;
            RTime2.setText(" " + pontot2);
        }
    }

    public void cBola3(View view){
        if (bt1.isChecked()){
            pontot1 = pontot1+3;
            RTime1.setText(" " + pontot1);
        }
        else if(bt2.isChecked()){
            pontot2 = pontot2+3;
            RTime2.setText(" " + pontot2);
        }
    }
}