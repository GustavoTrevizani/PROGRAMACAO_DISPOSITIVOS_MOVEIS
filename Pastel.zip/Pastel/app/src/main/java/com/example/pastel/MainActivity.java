package com.example.pastel;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.pastel.R;

public class MainActivity extends AppCompatActivity {

    private TextView numCliques;
    private TextView pontuacao;
    private int cliques = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        numCliques = findViewById(R.id.numCliques);
        pontuacao = findViewById(R.id.pontuacao);
        Button btnClique = findViewById(R.id.btnClique);
        Button btnEvoluir = findViewById(R.id.btnEvoluir);

        btnClique.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                contarClique();
            }
        });

        btnEvoluir.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                evoluirPontuacao();
            }
        });
    }

    private void contarClique() {
        cliques += 1;  // Incrementa o número de cliques
        numCliques.setText(String.valueOf(cliques));  // Atualiza o texto do número de cliques
    }

    private void evoluirPontuacao() {
        int pontos = (int) Math.pow(10, cliques);  // Calcula 10 elevado ao número de cliques
        pontuacao.setText(String.valueOf(pontos));  // Atualiza o texto da pontuação
    }
}