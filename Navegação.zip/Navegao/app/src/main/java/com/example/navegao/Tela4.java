package com.example.navegao;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Tela4 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela4);
    }

    public void Voltar(View view){
        Intent intent = new Intent(Tela4.this, TelaInicial.class);
        startActivity(intent);
    }
}