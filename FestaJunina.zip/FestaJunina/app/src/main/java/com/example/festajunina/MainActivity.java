package com.example.festajunina;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


    //Valores

    private int contador = 0;
    private float valorPescaria = 2.5f;
    private float valorPescariaPremium = 5;
    private float valorCadeia = 2;
    private float valorSaida = 4;
    private float valorVinganca = 5;
    private float valorPinhao = 3;
    private float valorBatata = 4;
    private float valorLabirinto = 4;

    private int quantTempPescaria = 0;
    private int quantTempPescariaPremium = 0;
    private int quantTempCadeia = 0;
    private int quantTempSaida = 0;
    private int quantTempVinganca = 0;
    private int quantTempLab = 0;
    private int quantTempPinhao = 0;
    private int quantTempBatata = 0;
    private int quantPescaria = 0;
    private int quantPescariaPremium = 0;
    private int quantCadeia = 0;
    private int quantSaida = 0;
    private int quantVinganca = 0;
    private int quantLabirinto = 0;
    private int quantPinhao = 0;
    private int quantBatata = 0;

    private TextView pesc;
    private TextView pescp;
    private TextView cadeia;
    private TextView saida;
    private TextView vinganca;
    private TextView lab;
    private TextView pinhao;
    private TextView batata;
    private TextView res;
    private Button botaorelatorio;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        pesc = findViewById(R.id.textViewpesc1);
        pescp = findViewById(R.id.textViewpesc2);
        cadeia = findViewById(R.id.textViewcadeia);
        saida = findViewById(R.id.textViewsaida);
        vinganca = findViewById(R.id.textViewvinganca);
        lab = findViewById(R.id.textViewlabirinto);
        pinhao = findViewById(R.id.textViewpinhao);
        batata = findViewById(R.id.textViewbatata);
        res = findViewById(R.id.textViewvalorfinal);
        botaorelatorio = findViewById(R.id.buttonrelatorio);
    }

    public void Pescaria(View view){
        quantTempPescaria = quantTempPescaria + 1;
        float valorT = quantTempPescaria * valorPescaria;
        pesc.setText("Pescaria   "+ quantTempPescaria + "  R$:" + valorT);
    }

    public void PescariaPremium(View view){
        quantTempPescariaPremium = quantTempPescariaPremium + 1;
        float valorT = quantTempPescariaPremium * valorPescariaPremium;
        pescp.setText("Pescaria Premium  "+ quantTempPescariaPremium + "  R$:" + valorT);
    }

    public void Cadeia(View view){
        quantTempCadeia = quantTempCadeia + 1;
        float valorT = quantTempCadeia * valorCadeia;
        cadeia.setText("Cadeia   "+ quantTempCadeia + "  R$:" + valorT);
    }

    public void Saida(View view){
        quantTempSaida = quantTempSaida + 1;
        float valorT = quantTempSaida * valorSaida;
        saida.setText("Saída   "+ quantTempSaida + "  R$:" + valorT);
    }

    public void Vinganca(View view){
        quantTempVinganca = quantTempVinganca + 1;
        float valorT = quantTempVinganca * valorVinganca;
        vinganca.setText("Vingança   "+ quantTempVinganca + "  R$:" + valorT);
    }

    public void Comprar(View view){
        botaorelatorio.setVisibility(View.INVISIBLE);
        contador = 0;
        quantPescaria = quantPescaria + quantTempPescaria;
        quantTempPescaria = 0;
        pesc.setText("");
        quantPescariaPremium = quantPescariaPremium + quantTempPescariaPremium;
        quantTempPescariaPremium = 0;
        pescp.setText("");
    }

    public void Cancelar(View view){
        contador = contador + 1;
        if(contador > 5){
            botaorelatorio.setVisibility(View.VISIBLE);
        }
    }
}